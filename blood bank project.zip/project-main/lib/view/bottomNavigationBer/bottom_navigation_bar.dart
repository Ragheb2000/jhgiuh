import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:project/view/ask%20for%20blood/ask_for_blood_screen.dart';
import 'package:project/view/donate/donate_screen.dart';
import 'package:project/view/profile/profile_screen.dart';
import '../home/home_screen.dart';

class BottomNavigationBarScreen extends StatefulWidget {

  @override
  State<BottomNavigationBarScreen> createState() => _BottomNavigationBarScreenState();
}

class _BottomNavigationBarScreenState extends State<BottomNavigationBarScreen> {

  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        onTap: (index){
          setState(() {
            selectedIndex = index;
          });
        },
        type: BottomNavigationBarType.fixed,
        backgroundColor: const Color.fromRGBO(161, 63, 63, 1.0),
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.black,
        iconSize: 30,
        currentIndex: selectedIndex,
        unselectedFontSize: 13,
        selectedFontSize: 15,
        items: <BottomNavigationBarItem>[
          const BottomNavigationBarItem(
            icon: Icon(
              Icons.home_outlined,
            ),
            label: 'Home',
          ),

          BottomNavigationBarItem(
            icon: Image.asset("assets/images/icons8-blood-donation-64.png", scale: 2, color: selectedIndex == 1? Colors.white : Colors.black,),
            label: 'Donate',
          ),

          BottomNavigationBarItem(
            icon: Image.asset("assets/images/icons8-blood-donation-64 2.png", scale: 2, color: selectedIndex == 2? Colors.white : Colors.black,),
            label: "Ask",
          ),

          const BottomNavigationBarItem(
            icon: Icon(
              Icons.person_outline,
            ),
            label: 'Profile',
          ),
        ],
      ),
      body: getScreen(),
    );
  }

  Widget getScreen(){
    if(selectedIndex == 0){
      return HomeScreen();
    }else if(selectedIndex == 1){
      return DonateScreen();
    }else if(selectedIndex == 2){
     return AskForBloodScreen();
    }else{
      return ProfileScreen();
    }
  }
}
