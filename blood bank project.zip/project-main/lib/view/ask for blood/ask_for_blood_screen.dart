import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../donor/donor_screen.dart';

User? loggedinUser;

class AskForBloodScreen extends StatefulWidget {

  @override
  State<AskForBloodScreen> createState() => _AskForBloodScreenState();
}

class _AskForBloodScreenState extends State<AskForBloodScreen> {

  final _auth = FirebaseAuth.instance;

  void initState() {
    super.initState();
    getCurrentUser();
  }

  void getCurrentUser() async {
    try {
      final user = await _auth.currentUser;
      if (user != null) {
        loggedinUser = user;
        setState(() {});
        print(user.email);
      }
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(246, 93, 93, 1.0),
      appBar: AppBar(
        backgroundColor: const Color.fromRGBO(246, 93, 93, 1.0),
        elevation: 0,
        iconTheme: const IconThemeData(
          color: Color.fromRGBO(246, 93, 93, 1.0),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(25.0),
        child: Column(
          children: [
            Center(
              child: Text(
                  "Which type\ndo you want?",
                style: TextStyle(
                  fontSize: 25.sp,
                  color: Colors.white,
                ),
              ),
            ),
            SizedBox(height: 50.h,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                circleBuilder(title: "A+", context: context),
                circleBuilder(title: "O+", context: context),
                circleBuilder(title: "B+", context: context),
              ],
            ),
            SizedBox(height: 50.h,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                circleBuilder(title: "AB+", context: context),
                circleBuilder(title: "B", context: context),
                circleBuilder(title: "A-", context: context),
              ],
            ),
            SizedBox(height: 50.h,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                circleBuilder(title: "O-", context: context),
                circleBuilder(title: "B-", context: context),
                circleBuilder(title: "AB-", context: context),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget circleBuilder({required String title, required BuildContext context}){
   return InkWell(
     onTap: (){
       if(loggedinUser != null){
         Navigator.push(context, MaterialPageRoute(builder: ((context) => DonorScreen(title))));
       }else{
         Widget okButton = TextButton(
           child: const Text("Done"),
           onPressed: () {
             Navigator.pop(context);
           },
         );
         AlertDialog alert = AlertDialog(
           content: Text("Please login first", style: TextStyle(fontSize: 20.sp),),
           actions: [
             okButton,
           ],
         );
         showDialog(
           context: context,
           builder: (BuildContext context) {
             return alert;
           },
         );
       }
     },
     child: CircleAvatar(
       backgroundColor: const Color.fromRGBO(161, 63, 63, 1.0),
       radius: 35.r,
        child: Center(child: Text(title, style: TextStyle(color: Colors.white, fontSize: 25.sp, fontWeight: FontWeight.bold),)),
     ),
   );
  }
}
