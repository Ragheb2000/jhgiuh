import 'package:conditional_builder_null_safety/conditional_builder_null_safety.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:project/view/authontication/login_screen.dart';
import 'edit_profile_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

User? loggedinUser;

class ProfileScreen extends StatefulWidget {
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {

  User? firebaseUser = FirebaseAuth.instance.currentUser;
  Map<String, dynamic>? userMap;
  bool get = false;

  final _auth = FirebaseAuth.instance;


  void initState() {
    super.initState();
    getCurrentUser();
  }

  void getCurrentUser() async {
    try {
      final user = await _auth.currentUser;
      if (user != null) {
        loggedinUser = user;
        setState(() {});
        print(user.email);
      }
    } catch (e) {
      print(e);
    }
  }

  void GetUserData() async {
    FirebaseFirestore _firestore = FirebaseFirestore.instance;
    await _firestore
        .collection('users')
        .where('id', isEqualTo: firebaseUser!.uid)
        .get()
        .then((value) {
      setState(() {
        userMap = value.docs[0].data();
        get = true;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    if(loggedinUser != null){
      GetUserData();
    }
    return Scaffold(
      backgroundColor: const Color.fromRGBO(246, 93, 93, 1.0),
      appBar: AppBar(
        backgroundColor: const Color.fromRGBO(246, 93, 93, 1.0),
        elevation: 0,
        title: Text(
          "Profile",
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30.sp),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: IconButton(
              onPressed: () {
                if(loggedinUser != null){
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: ((context) => EditProfileScreen(userMap!['name'], userMap!['phone'], FirebaseAuth.instance.currentUser!.email.toString()))));
                }else{
                  Widget okButton = TextButton(
                    child: const Text("Done"),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  );
                  AlertDialog alert = AlertDialog(
                    content: Text("Please login first", style: TextStyle(fontSize: 20.sp),),
                    actions: [
                      okButton,
                    ],
                  );
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return alert;
                    },
                  );
                }
              },
              icon: Icon(
                Icons.edit,
                color: Colors.white,
                size: 30.sp,
              ),
            ),
          ),
        ],
      ),
      body: ConditionalBuilder(
        condition: loggedinUser != null,
        fallback: (context) => Center(child: Text("Please Login First", style: TextStyle(fontSize: 25.sp, color: Colors.white),)),
        builder: (context) => ConditionalBuilder(
          condition: get,
          fallback: (context) => const Center(child: CircularProgressIndicator(color: Colors.white,)),
          builder: (context) => Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Text(
                  "Name: ${userMap!['name']}",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Text(
                  "Email: ${FirebaseAuth.instance.currentUser!.email.toString()}",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Text(
                  "Phone: ${userMap!['phone']}",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Text(
                  "Blood Type: ${userMap!['blood']}",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Container(
                  width: double.infinity,
                  height: 1.h,
                  color: Colors.white,
                ),
              ),
              SizedBox(
                height: 40.h,
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Text(
                  "History:",
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 22.sp),
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 10.h),
                child: Text(
                  "Donate on 16-feb-2022",
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 20.sp),
                ),
              ),
              SizedBox(
                height: 60.h,
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 25.w, vertical: 60.h),
                child: Center(
                  child: MaterialButton(
                    onPressed: () async {
                      await FirebaseAuth.instance.signOut().then((value) {
                        Navigator.pushReplacement(context,
                            MaterialPageRoute(builder: ((context) => LoginScreen())));
                      });
                    },
                    color: const Color.fromRGBO(161, 63, 63, 1.0),
                    shape: const StadiumBorder(),
                    minWidth: 300.w,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    child: Text(
                      "Log Out",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 25.sp,
                          fontWeight: FontWeight.bold,
                          fontFamily: "Open_Sans"),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
