import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class EditProfileScreen extends StatefulWidget {

  String name;
  String phone;
  String email;
  EditProfileScreen(this.name, this.phone, this.email);

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState(name, phone, email);
}

class _EditProfileScreenState extends State<EditProfileScreen> {

  String name;
  String phone;
  String email;
  _EditProfileScreenState(this.name, this.phone, this.email);

  var nameController = TextEditingController();
  var phoneController = TextEditingController();
  var emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {

    nameController = TextEditingController(text: name);
    phoneController = TextEditingController(text: phone);
    emailController = TextEditingController(text: email);

    return Scaffold(
      backgroundColor: const Color.fromRGBO(246, 93, 93, 1.0),
      appBar: AppBar(
        backgroundColor: const Color.fromRGBO(246, 93, 93, 1.0),
        elevation: 0,
        title: Text("Edit Profile", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30.sp),),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 70.h,),

              Text(
                  "Full Name",
                style: TextStyle(
                  fontSize: 25.sp,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20.h,),
              SizedBox(
                width: 300.w,
                child: TextFormField(
                  controller: nameController,
                  keyboardType: TextInputType.name,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18.sp,
                    fontWeight: FontWeight.bold
                  ),
                  decoration: InputDecoration(
                    hintStyle: TextStyle(
                      color: Colors.white,
                      fontSize: 20.sp,
                      fontWeight: FontWeight.w600,
                    ),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.3),
                    enabledBorder: const UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.transparent),
                    ),
                    focusedBorder: const UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.transparent),
                    ),
                  ),
                  cursorColor: Colors.white,
                ),
              ),
              SizedBox(height: 30.h,),

              Text(
                "Phone",
                style: TextStyle(
                  fontSize: 25.sp,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20.h,),
              SizedBox(
                width: 300.w,
                child: TextFormField(
                  controller: phoneController,
                  keyboardType: TextInputType.number,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18.sp,
                      fontWeight: FontWeight.bold
                  ),
                  decoration: InputDecoration(
                    hintStyle: TextStyle(
                      color: Colors.white,
                      fontSize: 20.sp,
                      fontWeight: FontWeight.w600,
                    ),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.3),
                    enabledBorder: const UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.transparent),
                    ),
                    focusedBorder: const UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.transparent),
                    ),
                  ),
                  cursorColor: Colors.white,
                ),
              ),

              SizedBox(height: 30.h,),

              Text(
                "Email",
                style: TextStyle(
                  fontSize: 25.sp,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20.h,),
              SizedBox(
                width: 300.w,
                child: TextFormField(
                  controller: emailController,
                  keyboardType: TextInputType.emailAddress,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18.sp,
                      fontWeight: FontWeight.bold
                  ),
                  decoration: InputDecoration(
                    hintStyle: TextStyle(
                      color: Colors.white,
                      fontSize: 20.sp,
                      fontWeight: FontWeight.w600,
                    ),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.3),
                    enabledBorder: const UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.transparent),
                    ),
                    focusedBorder: const UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.transparent),
                    ),
                  ),
                  cursorColor: Colors.white,
                ),
              ),

              SizedBox(height: 30.h,),

              Padding(
                padding: EdgeInsets.symmetric(vertical: 20.h),
                child: Center(
                  child: MaterialButton(
                    onPressed: () async{
                      User? firebaseUser = await FirebaseAuth.instance.currentUser;
                      final docUser = FirebaseFirestore.instance.collection('users').doc(firebaseUser!.uid);
                      if(nameController.text != name){
                        docUser.update({
                          'name': nameController.text,
                        });
                      }
                      if(phoneController.text != phone){
                        docUser.update({
                          'phone': phoneController.text,
                        });
                      }
                      if(emailController.text != email){
                        firebaseUser.updateEmail(emailController.text);
                      }
                      Navigator.pop(context);
                    },
                    color: const Color.fromRGBO(161, 63, 63, 1.0),
                    shape: const StadiumBorder(),
                    minWidth: 300.w,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    child: Text(
                      "Save",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 25.sp,
                          fontWeight: FontWeight.bold,
                          fontFamily: "Open_Sans"),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
