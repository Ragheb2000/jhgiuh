import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:conditional_builder_null_safety/conditional_builder_null_safety.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class DonorScreen extends StatefulWidget {
  String title;

  DonorScreen(this.title);

  @override
  State<DonorScreen> createState() => _DonorScreenState();
}

class _DonorScreenState extends State<DonorScreen> {
  List<Map<String, dynamic>> list = [];
  List<Map<String, dynamic>> final_list = [];
  bool get = false;

  void initState() {
    super.initState();
    GetUserData();
  }

  void GetUserData() async {
    FirebaseFirestore _firestore = FirebaseFirestore.instance;
    await _firestore
        .collection('users')
        .where('blood', isEqualTo: widget.title)
        .get()
        .then((value) {
      setState(() {
        for (int i = 0; i < value.docs.length; i++) {
          list.add(value.docs[i].data());
          if (list[i]['donation'].length > 1) {
            final_list.add(value.docs[i].data());
          }
          print(final_list);
        }
        get = true;
      });
    });
  }

  Set<Marker> _markers = Set<Marker>();

  void _setMarker(LatLng point){
    setState(() {
      _markers.add(
        Marker(markerId: MarkerId('marker'), position: point),
      );
    });
  }
  final Completer<GoogleMapController> _controller = Completer<GoogleMapController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(246, 93, 93, 1.0),
      appBar: AppBar(
        backgroundColor: const Color.fromRGBO(246, 93, 93, 1.0),
        elevation: 0,
        title: Text(
          "Donor",
          style: TextStyle(
              color: Colors.white,
              fontSize: 30.sp,
              fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.title,
                style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 30.sp),
              ),
              SizedBox(
                height: 40.h,
              ),
              ConditionalBuilder(
                condition: get,
                fallback: (context) => const Center(child: CircularProgressIndicator(color: Colors.white,)),
                builder: (context) => ConditionalBuilder(
                      condition: final_list.isNotEmpty,
                      fallback: (context) => Center(child: Column(
                                children: [
                                  SizedBox(
                                    height: 250.h,
                                  ),
                                  Text(
                                    "There are no donors at the moment",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 30.sp,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              )),
                      builder: (context) {
                        return Column(
                            children: [
                              for (int j = 0; j < final_list.length; j++)
                                for (int i = 1; i < final_list[j]['donation'].length; i++)
                                  Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 10),
                                    child: Container(
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10.r),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(15.0),
                              child: Row(
                                mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                                children: [
                                    Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Name: ${final_list[j]['name']}",
                                          style: TextStyle(
                                              fontSize: 20.sp,
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        SizedBox(
                                          height: 30.h,
                                        ),
                                        Text(
                                          "Phone: ${final_list[j]['phone']}",
                                          style: TextStyle(
                                              fontSize: 20.sp,
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ],
                                    ),
                                    InkWell(
                                      onTap: () {

                                        _setMarker(LatLng(final_list[j]['donation'][i]['lat'], final_list[j]['donation'][i]['lng']),);

                                        showModalBottomSheet(
                                            context: context,
                                            isScrollControlled: true,
                                            builder: (context) {
                                              return FractionallySizedBox(
                                                heightFactor: 1,
                                                child: Column(
                                                  children: [
                                                    SizedBox(height: 30.h,),
                                                    Row(
                                                      children: [
                                                        IconButton(
                                                          onPressed: () {
                                                            Navigator.pop(context);
                                                          },
                                                          icon: const Icon(Icons.arrow_back_ios),
                                                        ),
                                                      ],
                                                    ),
                                                    Expanded(
                                                      child: GoogleMap(
                                                        mapType: MapType.normal,
                                                        markers: _markers,
                                                        initialCameraPosition: CameraPosition(
                                                          target: LatLng(final_list[j]['donation'][i]['lat'], final_list[j]['donation'][i]['lng']),
                                                          zoom: 12,
                                                        ),
                                                        onMapCreated: (GoogleMapController controller) {
                                                          _controller.complete(controller);
                                                        },
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              );
                                            });
                                      },
                                      child: Icon(
                                        Icons.location_on,
                                        color: const Color.fromRGBO(
                                            246, 93, 93, 1.0),
                                        size: 60.sp,
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ),
                                  ),
                            ],
                        );
                      },
                    ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
