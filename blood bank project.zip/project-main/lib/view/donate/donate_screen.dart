import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../../map/location_service.dart';

User? loggedinUser;

class DonateScreen extends StatefulWidget {

  @override
  State<DonateScreen> createState() => _DonateScreenState();
}

class _DonateScreenState extends State<DonateScreen> {

  final _auth = FirebaseAuth.instance;

  void initState() {
    super.initState();
    getCurrentUser();
    _setMarker(LatLng(37.42796133580664, -122.085749655962));
  }

  void getCurrentUser() async {
    try {
      final user = await _auth.currentUser;
      if (user != null) {
        loggedinUser = user;
        setState(() {});
        print(user.email);
      }
    } catch (e) {
      print(e);
    }
  }

  DateTime selectedDate = DateTime.now();
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        firstDate: DateTime(2015, 8),
        lastDate: DateTime(2101));
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  String dropdownvalue = 'A+';
  var items = [
    'A+',
    'O+',
    'B+',
    'AB+',
    'B',
    'A-',
    'O-',
    'B-',
    'AB-',
  ];

  TextEditingController _searchController = TextEditingController();

  final Completer<GoogleMapController> _controller = Completer<GoogleMapController>();

  static const CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(31.963158, 35.930359),
    zoom: 14.4746,
  );

  Set<Marker> _markers = Set<Marker>();

  void _setMarker(LatLng point){
    setState(() {
      _markers.add(
        Marker(markerId: MarkerId('marker'), position: point),
      );
    });
  }

  var x;
  var y;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(246, 93, 93, 1.0),
      appBar: AppBar(
        backgroundColor: const Color.fromRGBO(246, 93, 93, 1.0),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(25.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Text(
                  "Schedule your donation\nappointment to donate",
                  style: TextStyle(
                    fontSize: 25.sp,
                    color: Colors.white.withOpacity(.7),
                  ),
                ),
              ),
              SizedBox(height: 50.h,),

              Text(
                "Calender",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 25.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20.h,),
              InkWell(
                onTap: (){
                  _selectDate(context);
                },
                child: Container(
                  color: Colors.white.withOpacity(.2),
                  width: double.infinity,
                  height: 80.h,
                  child:  Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Text("${selectedDate.toLocal()}".split(' ')[0], style: TextStyle(fontSize: 20.sp, color: Colors.white.withOpacity(.7)),),
                  ),
                ),
              ),

              SizedBox(height: 70.h,),

              Text(
                "Choose a donation place",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 25.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20.h,),
              Container(
                color: Colors.white.withOpacity(.2),
                width: double.infinity,
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 10.h),
                  child: InkWell(
                    onTap: (){
                      showModalBottomSheet(
                          context: context,
                          isScrollControlled: true,
                          builder: (context) {
                            return FractionallySizedBox(
                              heightFactor: 1,
                              child: Column(
                                children: [
                                  SizedBox(height: 30.h,),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: TextFormField(
                                          controller: _searchController,
                                          textCapitalization: TextCapitalization.words,
                                          decoration: const InputDecoration(
                                            hintText: "Search",
                                          ),
                                        ),
                                      ),
                                      IconButton(
                                        onPressed: () async{
                                          var place = await LocationService().getPlace(_searchController.text);
                                          _goToPlace(place);
                                        },
                                        icon: const Icon(Icons.search),
                                      ),
                                      IconButton(
                                        onPressed: () {
                                          Navigator.pop(context);
                                        },
                                        icon: const Icon(Icons.save),
                                      ),
                                    ],
                                  ),
                                  Expanded(
                                    child: GoogleMap(
                                      mapType: MapType.normal,
                                      markers: _markers,
                                      initialCameraPosition: _kGooglePlex,
                                      onMapCreated: (GoogleMapController controller) {
                                        _controller.complete(controller);
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            );
                          });
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: _searchController.text == ""? Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("Please select Location", style: TextStyle(color: Colors.white, fontSize: 20.sp),),
                          const Icon(Icons.arrow_forward_ios, color: Colors.white,),
                        ],
                      ) : Text(_searchController.text, style: TextStyle(color: Colors.white, fontSize: 18.sp),),
                    ),
                  ),
                ),
              ),

              SizedBox(height: 70.h,),

              Center(
                child: MaterialButton(
                  onPressed: () async{
                    if(loggedinUser != null){
                      User? firebaseUser = await FirebaseAuth.instance.currentUser;
                      appendToArray(firebaseUser!.uid, {
                        "data": selectedDate.toLocal().toString().split(' ')[0],
                        'lat': x,
                        'lng': y,
                        'location': _searchController.text,
                      }).then((value) {
                        Fluttertoast.showToast(
                            msg: "Success",
                            toastLength: Toast.LENGTH_SHORT,
                            gravity: ToastGravity.CENTER,
                            timeInSecForIosWeb: 3,
                            backgroundColor: Colors.green,
                            textColor: Colors.white,
                            fontSize: 16.0
                        );
                      });
                    }else{
                      Widget okButton = TextButton(
                        child: const Text("Done"),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                      );
                      AlertDialog alert = AlertDialog(
                        content: Text("Please login first", style: TextStyle(fontSize: 20.sp),),
                        actions: [
                          okButton,
                        ],
                      );
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return alert;
                        },
                      );
                    }
                  },
                  color: const Color.fromRGBO(161, 63, 63, 1.0),
                  shape: const StadiumBorder(),
                  minWidth: 350.w,
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  child: Text(
                    "Confirm\nappointment",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 20.sp,
                        fontWeight: FontWeight.bold,
                        fontFamily: "Open_Sans"),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  Future<void> _goToPlace(Map<String, dynamic> place)async{
    final double lat = place['geometry']['location']['lat'];
    final double lng = place['geometry']['location']['lng'];

    print(lat);
    print(lng);

    x = lat;
    y = lng;

    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.newCameraPosition(
      CameraPosition(target: LatLng(lat, lng), zoom: 12),
    ));
    print("##################");
    _setMarker(LatLng(lat, lng));
    print("************");
  }
}

Future<void> appendToArray(String id, dynamic element) async {
  FirebaseFirestore.instance.collection('users').doc(id).update({
    'donation': FieldValue.arrayUnion([element]),
  });
}