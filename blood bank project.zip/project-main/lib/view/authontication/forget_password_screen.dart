import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';

class FogetPasswordScreen extends StatelessWidget {

  var formKey = GlobalKey<FormState>();
  final _auth = FirebaseAuth.instance;
  var emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(246, 93, 93, 1.0),
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: const Color.fromRGBO(246, 93, 93, 1.0),
        elevation: 0,
      ),
      body: Column(
        children: [
          SizedBox(height: 50.h,),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Forget Password",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 35.sp,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ],
          ),

          SizedBox(height: 50.h,),

          Padding(
            padding: EdgeInsets.symmetric(horizontal: 25.w),
            child: TextFormField(
              controller: emailController,
              keyboardType: TextInputType.emailAddress,
              validator: (value) {
                if (value!.isEmpty) {
                  return 'please enter your email address';
                }
                else if(!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)){
                  return 'please enter correct email';
                }
              },
              style: const TextStyle(
                color: Colors.white,
              ),
              decoration: InputDecoration(
                hintText: "Email",
                hintStyle: TextStyle(
                  color: Colors.white,
                  fontSize: 20.sp,
                  fontWeight: FontWeight.w600,
                ),
                enabledBorder: const UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.white),
                ),
                focusedBorder: const UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.white),
                ),
              ),
              cursorColor: Colors.white,
            ),
          ),

          SizedBox(height: 50.h,),

          Padding(
            padding: EdgeInsets.symmetric(horizontal: 25.w, vertical: 10.h),
            child: Center(
              child: MaterialButton(
                onPressed: () async {
                  _auth.sendPasswordResetEmail(email: emailController.text).then((value) {
                    print("Send Success");
                    Widget okButton = TextButton(
                      child: const Text("OK"),
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                    );
                    AlertDialog alert = AlertDialog(
                      title: const Text("Forget Password"),
                      content: const Text("Please check your mail."),
                      actions: [
                        okButton,
                      ],
                    );
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return alert;
                      },
                    );
                  }).catchError((e){
                    Fluttertoast.showToast(
                        msg: e.toString().split(']').last,
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.CENTER,
                        timeInSecForIosWeb: 3,
                        backgroundColor: Colors.red,
                        textColor: Colors.white,
                        fontSize: 16.0
                    );
                  });
                },
                color: const Color.fromRGBO(161, 63, 63, 1.0),
                shape: const StadiumBorder(),
                minWidth: 300.w,
                elevation: 0,
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: Text(
                  "Send Email",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 25.sp,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Open_Sans"),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
