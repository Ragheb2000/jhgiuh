import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../model/user_data.dart';
import 'login_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';

class SignUpScreen extends StatefulWidget {

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {

  var nameController = TextEditingController();
  var emailController = TextEditingController();
  var passwordController = TextEditingController();
  var confirmPasswordController = TextEditingController();
  var phoneController = TextEditingController();

  var formKey = GlobalKey<FormState>();

  IconData suffix = Icons.visibility_outlined;
  bool isPassword = true;

  IconData suffix2 = Icons.visibility_outlined;
  bool isPassword2 = true;

  String dropdownvalue = 'Blood Type';
  var items = [
    'Blood Type',
    'A+',
    'O+',
    'B+',
    'AB+',
    'B',
    'A-',
    'O-',
    'B-',
    'AB-',
  ];

  @override
  void dispose(){
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  final _auth = FirebaseAuth.instance;
  bool showSpinner = false;

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Scaffold(
        backgroundColor: const Color.fromRGBO(246, 93, 93, 1.0),
        body: SafeArea(
          child: ModalProgressHUD(
            inAsyncCall: showSpinner,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.only(top: 50.h, bottom: 60.h),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "SignUp",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 35.sp,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ],
                    ),
                  ),

                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 25.w),
                    child: TextFormField(
                      controller: nameController,
                      keyboardType: TextInputType.emailAddress,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'please enter your name';
                        }
                      },
                      style: const TextStyle(
                        color: Colors.white,
                      ),
                      decoration: InputDecoration(
                        hintText: "Full name",
                        hintStyle: TextStyle(
                          color: Colors.white,
                          fontSize: 20.sp,
                          fontWeight: FontWeight.w600,
                        ),
                        enabledBorder: const UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                        ),
                        focusedBorder: const UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                        ),
                      ),
                      cursorColor: Colors.white,
                    ),
                  ),

                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 25.w, vertical: 30.h),
                    child: TextFormField(
                      controller: emailController,
                      keyboardType: TextInputType.emailAddress,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'please enter your email address';
                        }
                        else if(!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)){
                          return 'please enter correct email';
                        }
                      },
                      style: const TextStyle(
                        color: Colors.white,
                      ),
                      decoration: InputDecoration(
                        hintText: "Email",
                        hintStyle: TextStyle(
                          color: Colors.white,
                          fontSize: 20.sp,
                          fontWeight: FontWeight.w600,
                        ),
                        enabledBorder: const UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                        ),
                        focusedBorder: const UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                        ),
                      ),
                      cursorColor: Colors.white,
                    ),
                  ),

                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 25.w),
                    child: TextFormField(
                      controller: passwordController,
                      keyboardType: TextInputType.text,
                      obscureText: isPassword,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'please enter your password';
                        }
                      },
                      style: const TextStyle(
                        color: Colors.white,
                      ),
                      decoration: InputDecoration(
                        hintText: "Password",
                        hintStyle: TextStyle(
                          color: Colors.white,
                          fontSize: 20.sp,
                          fontWeight: FontWeight.w600,
                        ),
                        enabledBorder: const UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                        ),
                        focusedBorder: const UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                        ),
                        suffixIcon: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 25.w),
                          child: InkWell(
                            onTap: (){
                              isPassword = !isPassword;
                              suffix =
                              isPassword ? Icons.visibility_outlined : Icons.visibility_off_outlined;
                              setState(() {

                              });
                            },
                            child: Icon(
                              suffix,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      cursorColor: Colors.white,
                    ),
                  ),

                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 25.w, vertical: 30.h),
                    child: TextFormField(
                      controller: confirmPasswordController,
                      keyboardType: TextInputType.text,
                      obscureText: isPassword,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'please enter your Password';
                        }else if(passwordController.text != confirmPasswordController.text){
                          return 'you enter two different passwords';
                        }
                      },
                      style: const TextStyle(
                        color: Colors.white,
                      ),
                      decoration: InputDecoration(
                        hintText: "Confirm Password",
                        hintStyle: TextStyle(
                          color: Colors.white,
                          fontSize: 20.sp,
                          fontWeight: FontWeight.w600,
                        ),
                        enabledBorder: const UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                        ),
                        focusedBorder: const UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                        ),
                        suffixIcon: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 25.w),
                          child: InkWell(
                            onTap: (){
                              isPassword2 = !isPassword2;
                              suffix2 = isPassword2 ? Icons.visibility_outlined : Icons.visibility_off_outlined;
                              setState(() {

                              });
                            },
                            child: Icon(
                              suffix,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      cursorColor: Colors.white,
                    ),
                  ),

                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 25.w),
                    child: TextFormField(
                      controller: phoneController,
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'please enter your phone';
                        }
                      },
                      style: const TextStyle(
                        color: Colors.white,
                      ),
                      decoration: InputDecoration(
                        hintText: "Phone",
                        hintStyle: TextStyle(
                          color: Colors.white,
                          fontSize: 20.sp,
                          fontWeight: FontWeight.w600,
                        ),
                        enabledBorder: const UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                        ),
                        focusedBorder: const UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                        ),
                      ),
                      cursorColor: Colors.white,
                    ),
                  ),

                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 25.w, vertical: 30.h),
                    child: DropdownButtonFormField(
                      value: dropdownvalue,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'please enter your blood type';
                        }
                      },
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 20.sp
                      ),
                      icon: const Icon(Icons.keyboard_arrow_down, color: Colors.white, size: 30,),
                      dropdownColor: const Color.fromRGBO(161, 63, 63, 1.0),
                      items: items.map((String items) {
                        return DropdownMenuItem(
                          value: items,
                          child: Text(items),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          dropdownvalue = newValue!;
                        });
                      },
                    ),
                  ),

                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 25.w, vertical: 10.h),
                    child: Center(
                      child: MaterialButton(
                        onPressed: () async{
                          if(formKey.currentState!.validate()){
                            if(passwordController.text == confirmPasswordController.text){
                              setState(() {
                                showSpinner = true;
                              });
                              try {
                                final newUser = await _auth.createUserWithEmailAndPassword(
                                    email: emailController.text.trim(), password: passwordController.text.trim());
                                if (newUser != null){
                                  User? firebaseUser = await FirebaseAuth.instance.currentUser;
                                  final docUser = FirebaseFirestore.instance.collection('users').doc(firebaseUser!.uid);
                                  final user = UserModel(
                                      id: firebaseUser.uid,
                                      name: nameController.text,
                                      phone: phoneController.text,
                                      blood: dropdownvalue,
                                      donation: [{}],
                                  );
                                  final json = user.toJson();
                                  await docUser.set(json);
                                  Navigator.pushReplacement(context, MaterialPageRoute(builder: ((context) => LoginScreen())));
                                }
                              } catch (e) {
                                print(e);
                              }
                              setState(() {
                                showSpinner = false;
                              });
                            }
                          }
                        },
                        color: const Color.fromRGBO(161, 63, 63, 1.0),
                        shape: const StadiumBorder(),
                        minWidth: 300.w,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                        child: Text(
                          "Sign up",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 25.sp,
                              fontWeight: FontWeight.bold,
                              fontFamily: "Open_Sans"),
                        ),
                      ),
                    ),
                  ),

                  Padding(
                    padding: EdgeInsets.only(left: 25.w, right: 25.w, top: 20.h),
                    child: InkWell(
                      onTap: (){
                        Navigator.pushReplacement(context, MaterialPageRoute(builder: ((context) => LoginScreen())));
                      },
                      child: Text(
                        "Already have an account? Login",
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 20.sp
                        ),
                      ),
                    ),
                  ),

                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
