import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import '../bottomNavigationBer/bottom_navigation_bar.dart';
import 'forget_password_screen.dart';
import 'sign_up_screen.dart';
import 'package:fluttertoast/fluttertoast.dart';

class LoginScreen extends StatefulWidget {

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  var emailController = TextEditingController();

  var passwordController = TextEditingController();

  IconData suffix = Icons.visibility_outlined;

  bool isPassword = true;

  var formKey = GlobalKey<FormState>();

  final _auth = FirebaseAuth.instance;
  bool showSpinner = false;

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Scaffold(
        backgroundColor: const Color.fromRGBO(246, 93, 93, 1.0),
        resizeToAvoidBottomInset: false,
        body: SafeArea(
          child: ModalProgressHUD(
            inAsyncCall: showSpinner,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(top: 50.h, bottom: 60.h),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                          "LOGIN",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 35.sp,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 50.h,),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 25.w),
                  child: TextFormField(
                    controller: emailController,
                    keyboardType: TextInputType.emailAddress,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'please enter your email address';
                      }
                      else if(!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)){
                        return 'please enter correct email';
                      }
                    },
                    style: const TextStyle(
                      color: Colors.white,
                    ),
                    decoration: InputDecoration(
                      hintText: "Email",
                      hintStyle: TextStyle(
                        color: Colors.white,
                        fontSize: 20.sp,
                        fontWeight: FontWeight.w600,
                      ),
                      enabledBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.white),
                      ),
                      focusedBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.white),
                      ),
                    ),
                    cursorColor: Colors.white,
                  ),
                ),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 25.w, vertical: 40.h),
                  child: TextFormField(
                    controller: passwordController,
                    keyboardType: TextInputType.text,
                    obscureText: isPassword,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'please enter your password';
                      }
                    },
                    style: const TextStyle(
                      color: Colors.white,
                    ),
                    decoration: InputDecoration(
                      hintText: "Password",
                      hintStyle: TextStyle(
                        color: Colors.white,
                        fontSize: 20.sp,
                        fontWeight: FontWeight.w600,
                      ),
                      enabledBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.white),
                      ),
                      focusedBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.white),
                      ),
                      suffixIcon: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 25.w),
                        child: InkWell(
                          onTap: (){
                            isPassword = !isPassword;
                            suffix =
                            isPassword ? Icons.visibility_outlined : Icons.visibility_off_outlined;
                            setState(() {

                            });
                          },
                          child: Icon(
                            suffix,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    cursorColor: Colors.white,
                  ),
                ),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 25.w, vertical: 30),
                  child: InkWell(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: ((context) => FogetPasswordScreen())));
                    },
                    child: Text(
                        "Forget Password?",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 18.sp
                      ),
                    ),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 25.w, vertical: 10.h),
                  child: Center(
                    child: MaterialButton(
                        onPressed: () async {
                          setState(() {
                            showSpinner = true;
                          });
                          try {
                            final user = await _auth.signInWithEmailAndPassword(email: emailController.text.trim(), password: passwordController.text.trim());
                            if (user != null) {
                              Fluttertoast.showToast(
                                  msg: "Login Success",
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.CENTER,
                                  timeInSecForIosWeb: 3,
                                  backgroundColor: Colors.green,
                                  textColor: Colors.white,
                                  fontSize: 16.0
                              );
                              Navigator.pushReplacement(context, MaterialPageRoute(builder: ((context) => BottomNavigationBarScreen())));
                            }
                          } catch (e) {
                            Fluttertoast.showToast(
                                msg: e.toString().split(']').last,
                                toastLength: Toast.LENGTH_SHORT,
                                gravity: ToastGravity.CENTER,
                                timeInSecForIosWeb: 3,
                                backgroundColor: Colors.red,
                                textColor: Colors.white,
                                fontSize: 16.0
                            );
                          }
                          setState(() {
                            showSpinner = false;
                          });
                        },
                      color: const Color.fromRGBO(161, 63, 63, 1.0),
                      shape: const StadiumBorder(),
                      minWidth: 300.w,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                      child: Text(
                        "Login",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 25.sp,
                            fontWeight: FontWeight.bold,
                            fontFamily: "Open_Sans"),
                      ),
                    ),
                  ),
                ),

                const Spacer(),

                Padding(
                  padding: EdgeInsets.only(left: 25.w, right: 25.w, bottom: 20.h),
                  child: Text(
                    "don't have any account?",
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 25.sp
                    ),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.only(left: 25.w, right: 25.w, bottom: 70.h),
                  child: Center(
                    child: InkWell(
                      onTap: (){
                        Navigator.pushReplacement(context, MaterialPageRoute(builder: ((context) => SignUpScreen())));
                      },
                      child: Text(
                        "Sign Up",
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 25.sp
                        ),
                      ),
                    ),
                  ),
                ),

              ],
            ),
          ),
        ),
      ),
    );
  }
}
