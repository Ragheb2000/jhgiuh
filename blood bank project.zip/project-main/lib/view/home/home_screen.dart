import 'package:carousel_nullsafety/carousel_nullsafety.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:conditional_builder_null_safety/conditional_builder_null_safety.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:geocoding/geocoding.dart';
import 'package:project/view/authontication/login_screen.dart';
import 'package:project/view/authontication/sign_up_screen.dart';

User? loggedinUser;

class HomeScreen extends StatefulWidget {

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {


  final _auth = FirebaseAuth.instance;
  User? firebaseUser = FirebaseAuth.instance.currentUser;
  Map<String, dynamic>? userMap;
  bool get = false;
  bool get2 = false;


  void initState() {
    super.initState();
    getCurrentUser();
  }

  void getCurrentUser() async {
    try {
      final user = await _auth.currentUser;
      if (user != null) {
        loggedinUser = user;
        setState(() {});
        GetUserData();
        get = true;
      }
    } catch (e) {
      print(e);
    }
  }

  void GetUserData() async {
    FirebaseFirestore _firestore = FirebaseFirestore.instance;
    await _firestore
        .collection('users')
        .where('id', isEqualTo: firebaseUser!.uid)
        .get()
        .then((value) {
      setState(() {
        userMap = value.docs[0].data();
        get2 = true;
      });
    });
  }

  List<String> list = ["assets/images/IMG_4357.JPG", "assets/images/IMG_4358.PNG", "assets/images/IMG_4359.JPG"];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(246, 93, 93, 1.0),
      appBar: AppBar(
        backgroundColor: const Color.fromRGBO(246, 93, 93, 1.0),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Home",
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 30.sp
                  ),
                ),
              ],
            ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Material(
                elevation: 5,
                borderRadius: BorderRadius.circular(20.r),
                child: Container(
                  height: 170.0,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20.r),
                  ),
                  child: Center(
                    child: ListView(
                      children: [
                        Container(
                          height: 170.0,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20.r),
                          ),
                          child: Carousel(
                            dotSize: 0,
                            dotSpacing: 0,
                            radius: Radius.circular(20.r),
                            borderRadius: true,
                            showIndicator: false,
                            dotPosition: DotPosition.bottomCenter,
                            images: [
                              for(int i =0 ; i < list.length; i++)
                                Container(
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20.r),
                                    image: DecorationImage(
                                      fit: BoxFit.cover,
                                      image: AssetImage(list[i]),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),


            loggedinUser == null? Container() :Padding(
              padding: const EdgeInsets.all(15.0),
              child: Text(
                  "Coming Appointment",
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 30.sp
                ),
              ),
            ),

            loggedinUser == null? Container() : ConditionalBuilder(
              condition: get && get2,
              fallback: (context) => Center(child: const CircularProgressIndicator(color: Colors.white,)),
              builder: (context) => ConditionalBuilder(
                condition: userMap!['donation'].length > 1,
                fallback: (context) => Center(child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 150),
                  child: Text("No Appointment Found", style: TextStyle(color: Colors.white, fontSize: 20.sp),),
                )),
                builder: (context){
                  return Column(
                    children: [
                      for(int i = 0; i < userMap!['donation'].length - 1; i++)
                        Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10.r),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("Date: ${userMap!['donation'][i + 1]['data']}", style: TextStyle(fontSize: 20.sp, color: Colors.black, fontWeight: FontWeight.bold),),
                                SizedBox(height: 20.h,),
                                Text("Location: ${userMap!['donation'][i + 1]['location']}", style: TextStyle(fontSize: 20.sp, color: Colors.black, fontWeight: FontWeight.bold),),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                }
              ),
            ),
            loggedinUser == null? Container() : Container(),
            loggedinUser != null? Container() : Padding(
              padding: EdgeInsets.only(bottom: 60.h, top: 200),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    onTap: (){
                      Navigator.pushReplacement(context, MaterialPageRoute(builder: ((context) => LoginScreen())));
                    },
                    child: Text(
                        "Login",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 25.sp,
                        fontWeight: FontWeight.bold
                      ),
                    ),
                  ),
                  Text(
                      " or ",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 25.sp,
                        fontWeight: FontWeight.bold
                    ),
                  ),

                  InkWell(
                    onTap: (){
                      Navigator.pushReplacement(context, MaterialPageRoute(builder: ((context) => SignUpScreen())));
                    },
                    child: Text(
                        "SignUp",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 25.sp,
                          fontWeight: FontWeight.bold
                      ),
                    ),
                  ),
                ],
              ),
            ),

          ],
        ),
      ),
    );
  }
}