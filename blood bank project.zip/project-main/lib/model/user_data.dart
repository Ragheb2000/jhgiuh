class UserModel{

  String id;
  final String name;
  final String phone;
  final String blood;
  final List donation;

  UserModel({
    this.id = '',
    required this.name,
    required this.phone,
    required this.blood,
    required this.donation,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'phone': phone,
    'blood': blood,
    'donation': donation,
  };

  static UserModel fromJson(Map<String, dynamic> json) => UserModel(
      name: json['name'],
      phone: json['phone'],
      blood: json['blood'],
      donation: json['donation'],
  );
}